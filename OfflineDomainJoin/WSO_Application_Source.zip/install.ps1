$Destination = "C:\Temp"

if(!(Test-Path $Destination))
{
    New-Item $Destination -ItemType Directory -Force
}
Copy-Item "$PSScriptRoot\ODJSource" -Destination $Destination -Force -Recurse