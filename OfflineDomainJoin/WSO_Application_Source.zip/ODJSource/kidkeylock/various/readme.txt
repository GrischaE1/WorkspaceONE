Freeware Disclaimer

Kid Key Lock is freeware. The author, of this software accepts no 
responsibility for damages resulting from the use of this product 
and makes no warranty or representation, either express or implied, 
including but not limited to, any implied warranty of merchantability 
or fitness for a particular purpose. This software is provided "AS IS", 
and you, its user, assume all risks when using it.